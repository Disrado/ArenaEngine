#ifndef SCENE_NODE_HPP
#define SCENE_NODE_HPP

#include <AE/Graphics/SceneNode.hpp>
#include <AE/Graphics/Object.hpp>


/*
class SceneNode_Test : public Test
{
    
    void createChildSceneNode_Test();
    void addChild_Test();
    void removeChild_Test();
    void removeChildren_Test();
    void destroyChild_Test();
    void destroyChildren_Test();

    void rebaseToNewParent_Test();
    void rebaseChildrenToNewParent_Test();

    void getDescendantCount_Test();
    void setVisibleRecursive_Test();

    void attachObject_Test();
    void detachObject_Test();
    void detachAllObjects_Test();
    void getAttachedObject_Test();

    void getDrawableObjects_Test();
    void getDrawableChildren_Test();

    void setDrawOrder_Test();
    void changeObjectDrawOrder_Test();

    void setOriginRecursive_Test();
    void setScaleRecursive_Test();
    void setPositionRecursive_Test();
    void setRotationRecursive_Test();
    void moveRecursive_Test();
    void rotateRecursive_Test();
    void scaleRecursive_Test();
    
public:
    void beginTests() override;
};
*/    
#endif //SCENENODE_HPP_TEST
